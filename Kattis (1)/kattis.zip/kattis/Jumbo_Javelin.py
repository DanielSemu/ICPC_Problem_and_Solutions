x=int(input())
sum=0
for i in range(x):
    sum+=int(input())
print(sum-(x-1))

