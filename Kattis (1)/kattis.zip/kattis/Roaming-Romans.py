x=float(input())
z=(x*1000*5280)/4854
print(round(z))