# x,y,z=map(int, input().split())
# print(x*z*y)
x=input()		
if (x=='OCT 31' or x=='DEC 25'):		
    print("yup")		
else:		   
    print("nope")