x=input()
for i in range(3):
    print(x,end=" ")