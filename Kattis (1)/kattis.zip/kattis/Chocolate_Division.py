
x,y = map(int,input().split())
a = x*y
if a%2==1:
    print("Beata")
if a%2==0:
    print("Alf")