x=int(input())
for i in range(x):
    num=int(input())
    if num%2==0:
        print(num ," is even")
    else:
        print(num, " is odd")