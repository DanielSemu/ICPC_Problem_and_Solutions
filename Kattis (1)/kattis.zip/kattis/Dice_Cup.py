x=input()
z=len(x)
count=0
for i in range(z-1):
    if x=='(':
        break
    else:
        count+=1
    
        
    