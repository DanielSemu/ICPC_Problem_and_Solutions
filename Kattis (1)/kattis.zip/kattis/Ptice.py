x=int(input())
y=input()
