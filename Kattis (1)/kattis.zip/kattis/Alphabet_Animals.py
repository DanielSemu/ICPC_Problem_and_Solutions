x=input()
len1=len(x)
num=int(input())
arr=[]
for i in range(num):
    arr[i]=input()

