x,y =map(int,input().split())
print(x+y)
print("hello")
