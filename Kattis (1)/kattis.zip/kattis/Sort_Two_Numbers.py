x,y=map(int, input().split())
if(x<y):
    print(x," ",y)
else:
    print(y," ",x)
# n=int(input())
# print((n*(n+1))//2)