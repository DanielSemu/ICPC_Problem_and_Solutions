x,y=map(int, input().split())
R2=2*y-x
print(R2)