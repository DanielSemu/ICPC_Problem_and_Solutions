x=int(input())
list=[]
for i in range(x):
    list.append(input())
for i in range(x):
    if i%2==0:
        print(list[i])


