
#coding is boring
a1,a2,a3=input().split()
tup={len(a1):a1 , len(a2):a2 ,len(a3):a3}
#tup.sort()
for x in tup:
    print(x)

 

