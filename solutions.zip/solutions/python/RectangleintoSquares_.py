# le lng!=wdth:
#         list.append(wdth)
#         lng=lng-wdth
#         if lng<wdth:
#             lng,wdth=wdth,lng
#     list.append(wdth)
#     retudef sqr(lng, wdth):
#     if lng==wdth:
#         return {}
#     list=[]
#     if lng<wdth:
#             lng,wdth=wdth,lng 
#     whirn list
# x,y=map(int,input().split())
# lst=sqr(x,y)
# print("{",end="")
# for i in range(len(lst)):
#     print(lst[i],end="")
#     if len(lst)-1 != i:
#         print(", ",end="")
# print("}")