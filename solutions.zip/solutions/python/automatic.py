n=int(input())

for i in range(n):
    s=int(input())
    a=s*567
    b=a/9

    c=b+7492
    d=c*235
    e=d/47
    f=int(e-498)
    length=str(f)
    m=str(f)
    ans=m[-2]


    print(ans)
