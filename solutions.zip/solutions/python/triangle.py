from cmath import sin


print(sin(30))