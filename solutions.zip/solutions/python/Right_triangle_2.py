x=int(input())
