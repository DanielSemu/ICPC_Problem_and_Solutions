while(True):
    x=int(input())
    if x== -1:
        break
    print(x+2)