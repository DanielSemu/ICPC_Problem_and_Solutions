num = []
try:
    while True:
        strn = input()
        l = list(strn.split())
        s = set(l)
        print(len(s))
except:
    pass


