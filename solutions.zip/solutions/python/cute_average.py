x,y=map(int,input().split())
z=(2*x*y)/(x+y)
print('%0.5f' %z)
#the formart is in