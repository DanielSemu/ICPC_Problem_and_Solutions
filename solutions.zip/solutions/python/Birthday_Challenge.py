t=int(input())
while t>0:
    x=int(input())
    print((x*(x+1))//2 + x)
    t-=1