x=int(input())
for i in range(x):
    x=input()
    