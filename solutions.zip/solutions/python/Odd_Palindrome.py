x= input()
if len(x)%2==0:
    print('Or not.')
else:
    print('Odd.')