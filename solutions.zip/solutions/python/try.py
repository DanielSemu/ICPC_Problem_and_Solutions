print("hello world")
e=input()
print(e)