
	cin>>t;