import statistics
n=int(input())
t=int(input())
# for x in range(n):
#     list[x]=input()
if(t==1):
    print("")
elif(t==2):
     
    print(statistics.mode(2,3,4,5))
elif(t==3):
    print("")
elif(t==4):
    print("")
elif(t==5):
    print("")