x = [list(i) for i in input().split()]

x = set(x)
for i in x:
    print(i, ' ')