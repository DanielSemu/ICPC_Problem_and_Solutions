x = int(input())
for i in range(x):
    v = int(input())
    k = int((((((v*567)/9)+7492)*235)/47)-498)
    r = str(k)
    print(r[(len(r)-2)])