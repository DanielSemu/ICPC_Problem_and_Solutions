area=int(input("enter"))
lenght=int(input())
l1=lenght/4
a1=l1**2
if (a1 == area):
    print("Diablo is happy!")
else:
    print("Need more materials!")