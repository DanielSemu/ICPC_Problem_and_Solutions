import math
n= int(input("enter "))
#first method
# z=0
# for x in range(1,(n+1)):
#     z=z+x
# print(4*z)
# second method
p=2*n*(n+1)
print(p)