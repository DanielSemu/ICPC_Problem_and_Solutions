x=input()
len=len(x)-2
print(x[0],end="")
for i in range(len*2):
    print("e",end="")
print("y")