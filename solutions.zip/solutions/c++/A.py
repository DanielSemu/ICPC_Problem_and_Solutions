n=int(input())

print(int((n*(n+1)))/2)