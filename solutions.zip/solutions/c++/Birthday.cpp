#include <bits/stdc++.h>
using namespace std;
int main(){
int t;
cin>>t;
	int d, sum =0;

	for(int j=0; j<t; j++){
		sum = 0;
      cin>>d;
	sum = (d*(d+3))/2;
	
	
	cout<<sum<<endl;
	}
	return 0;
}
