#include <bits/stdc++.h>
#include <String>>
using namespace std;
int main(){
	vector <pair<String><int>> value;
	int x ,sum=0;
	cin>>x;
	for (int i=0; i<x; i++){
		cin>>value.first()>>value.second();
	}
	for (int i=0; i<x; i++)
   {
	if(value.first == "bool"){
		sum = sum + (value.second);
	}
	}	
	
return 0;	
}

