#include <bits/stdc++.h>
using namespace std;
int main()
{
	string x;
	cin>>x;
	char a[sizeof(x)];
	for (int i=0; i<sizeof(x); i++){
		a[i]= x[i];
	}
	
	
//	for (int i=0; i<sizeof(x); i++){
//		
////		if(a[i]=="y")
////		sum+=int(arr[i])
////		cout<<a[i]<<" ";
//	}
cout<<int(a[0]);
	
	
}

