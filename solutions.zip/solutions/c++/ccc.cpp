#include <bits/stdc++.h>
using namespace std;
int main(){
	
	int i=766;
	int x,y,z,s;
	x=++i;
	y=i++;
	z=i--;
	s=--i;
	cout<<x<<endl;
	cout<<y<<endl;
	cout<<z<<endl;
	cout<<s<<endl;
	
}
