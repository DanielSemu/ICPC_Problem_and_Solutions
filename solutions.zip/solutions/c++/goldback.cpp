#include <bits/stdc++.h>
using namespace std;

void isPrime(int n){
	if (n<=1){
	   
	}
	for (int i=n; i>0; i--){
		if(n%i!=0){
			
			}
		
			
			return i;
		}	
		
	}

	
}
int main(){
long long int x, res;
 cin>>x;
	while(x!=-1){	
	
	if(x==-1)
		break;
	int v = n/2;
			
			
	isPrime(v);
	cin>>x;
}
return 0;
}

	
