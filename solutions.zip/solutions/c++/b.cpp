#include <bits/stdc++.h>
using namespace std;
int main(){
float x,y;
int t;
cin>>t;0t,
for (int i=1; i<=t; i++){
	cin>>x>>y;
	cout<<"Case "<<i<<": "<<(x*0.5)+(y*0.05)<<endl;
} 

	
	
return 0;
}
