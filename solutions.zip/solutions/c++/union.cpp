#include <bits/stdc++.h>
using namespace std;
int main(){
	long long int x, y, z;
	cin>>x>>y>>z;
	if((y+z)>x){
		cout<<(y+z)-x<<endl;
	}
	else{
		cout<<0<<endl;
	}
	
	
return 0;	
}
