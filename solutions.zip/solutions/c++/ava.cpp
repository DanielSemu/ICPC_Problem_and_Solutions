#include <bits/stdc++.h>
using namespace std;
int main(){
	float x,y,z;
	cin>>x>>y;
	
	z = (2*x*y)/(x+y);
	fprintf(stdout, "%.5f",z);
}
