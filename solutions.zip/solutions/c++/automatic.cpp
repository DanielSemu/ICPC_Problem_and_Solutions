#include <bits/stdc++.h>
using namespace std;
int main() {
long long int t, n;
cin>>t;
for (int i = 0; i< t; i++){
	cin>>n;
	cout<<(((((n*567)/9)+7492)*235)/47)-498<<endl;
}	
	
	
	return 0;
}
