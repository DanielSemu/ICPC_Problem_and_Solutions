#include <bits/stdc++.h>
using namespace std;

int main(){
long long int x,y,z;
cin>>x>>y>>z;
cout<<(x+y)%z<<" "<<(x-y)%z<<" "<<(x*y)%z;
return 0;	
}
